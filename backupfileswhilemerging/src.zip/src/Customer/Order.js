/** @format */

import React from "react";

const Order = () => {
	return (
		<div>
			<h1>Order....</h1>
		</div>
	);
};

export default Order;
