// export const baseURL = "http://172.16.20.61:5016"

export const baseURL = "http://172.16.20.61:5012"
export const baseURL1 = "http://172.16.20.61:5006"



// export const baseURL ="http://192.168.1.25:5016"
// export const baseURL1 = "http://192.168.1.25:5007"



// export const baseURL = "http://localhost:5010"


