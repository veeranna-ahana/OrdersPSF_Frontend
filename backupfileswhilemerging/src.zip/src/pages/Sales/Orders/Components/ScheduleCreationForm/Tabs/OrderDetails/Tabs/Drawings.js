import React from "react";

function Drawings() {
  return <div style={{fontSize:'12px'}}>Drawings Tab</div>;
}

export default Drawings;
