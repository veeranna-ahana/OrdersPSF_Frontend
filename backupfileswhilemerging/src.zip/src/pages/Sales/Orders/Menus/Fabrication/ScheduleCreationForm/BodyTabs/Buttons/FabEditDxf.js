import React from "react";

function FabEditDxf() {
  return (
    <div>
      <div className="mt-3">
        <h5>
          <b>Part Name</b>
        </h5>
        <h6>
          <b>Process</b>
        </h6>
        <h6>
          <b>Material Grade</b>
        </h6>
        <h6>
          <b>Material Source</b>
        </h6>
        <h6>
          <b>Order Qty</b>
        </h6>
      </div>
    </div>
  );
}

export default FabEditDxf;
