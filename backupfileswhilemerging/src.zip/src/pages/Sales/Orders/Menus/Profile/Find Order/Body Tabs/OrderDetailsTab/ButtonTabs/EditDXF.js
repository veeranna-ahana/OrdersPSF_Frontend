import React from 'react'

export default function EditDXF() {
  return (
    <div>
        <h5><b>Part Name</b></h5>
        <h6><b>Process</b></h6>
        <h6><b>Material Grade</b></h6>
        <h6><b>Material Source</b></h6>
        <h6><b>Order Qty</b></h6>
    </div>
  )
}
