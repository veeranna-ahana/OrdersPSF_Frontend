import React from "react";

function Mapping() {
  return <div>Mapping</div>;
}

export default Mapping;
