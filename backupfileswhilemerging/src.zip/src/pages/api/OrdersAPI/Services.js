import { url } from "../../API";

export const apipoints = {
  getCustomerdata: `${url}/customerdata/allcustomerdata`,
};
