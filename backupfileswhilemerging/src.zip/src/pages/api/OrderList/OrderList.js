import { url } from "../API";

export const apipoints = {
  getOrderListByType: `${url}/orderList/getOrderListByType`,
  getOrderListByTypeGroupedCustomer: `${url}/orderList/getOrderListByTypeGroupedCustomer`,
};
